<?php
class Pelanggaran_model extends CI_Model
{
	function get_all_pelanggaran()
	{ 
		return $this->db->query("SELECT pelanggaran.id_pelanggaran, pelanggaran.NIK, pelanggaran.nama_pegawai, pelanggaran.kode_kantor, pelanggaran.jenis_pelanggaran, pelanggaran.status_pelanggaran FROM pelanggaran WHERE pelanggaran.status_pelanggaran = 1"); 
	}

	function get_all_paging_sorting_pelanggaran($jtStartIndex,$jtPageSize,$jtSorting)
	{	
		return $this->db->query("SELECT pelanggaran.id_pelanggaran, pelanggaran.NIK, pelanggaran.nama_pegawai, pelanggaran.kode_kantor, pelanggaran.jenis_pelanggaran, pelanggaran.status_pelanggaran FROM pelanggaran WHERE pelanggaran.status_pelanggaran = 1 ORDER BY " . $jtSorting . " LIMIT " . $jtStartIndex . "," . $jtPageSize . ";"); 
	} 

	function post_invalid_pelanggaran($id_pelanggaran,$ket)
	{
		return $this->db->query("UPDATE pelanggaran SET pelanggaran.keterangan = '".$ket."', pelanggaran.status_pelanggaran = 2 WHERE pelanggaran.id_pelanggaran = '".$id_pelanggaran."';");
	}

	function post_valid_pelanggaran($id_pelanggaran)
	{
		return $this->db->query("UPDATE pelanggaran SET pelanggaran.status_pelanggaran = 3 WHERE pelanggaran.id_pelanggaran = '".$id_pelanggaran."';");
	}

	function get_all_pelanggaran_valid()
	{ 
		return $this->db->query("SELECT pelanggaran.id_pelanggaran, pelanggaran.NIK, pelanggaran.nama_pegawai, pelanggaran.kode_kantor, pelanggaran.jenis_pelanggaran, pelanggaran.status_pelanggaran FROM pelanggaran WHERE pelanggaran.status_pelanggaran = 3"); 
	}

	function get_all_paging_sorting_pelanggaran_valid($jtStartIndex,$jtPageSize,$jtSorting)
	{	
		return $this->db->query("SELECT pelanggaran.id_pelanggaran, pelanggaran.NIK, pelanggaran.nama_pegawai, pelanggaran.kode_kantor, pelanggaran.jenis_pelanggaran, pelanggaran.status_pelanggaran FROM pelanggaran WHERE pelanggaran.status_pelanggaran = 3 ORDER BY " . $jtSorting . " LIMIT " . $jtStartIndex . "," . $jtPageSize . ";"); 
	}

	function get_all_pelanggaran_invalid()
	{ 
		return $this->db->query("SELECT pelanggaran.id_pelanggaran, pelanggaran.NIK, pelanggaran.nama_pegawai, pelanggaran.kode_kantor, pelanggaran.jenis_pelanggaran, pelanggaran.status_pelanggaran FROM pelanggaran WHERE pelanggaran.status_pelanggaran = 2"); 
	}

	function get_all_paging_sorting_pelanggaran_invalid($jtStartIndex,$jtPageSize,$jtSorting)
	{	
		return $this->db->query("SELECT pelanggaran.id_pelanggaran, pelanggaran.NIK, pelanggaran.nama_pegawai, pelanggaran.kode_kantor, pelanggaran.jenis_pelanggaran, pelanggaran.status_pelanggaran FROM pelanggaran WHERE pelanggaran.status_pelanggaran = 2 ORDER BY " . $jtSorting . " LIMIT " . $jtStartIndex . "," . $jtPageSize . ";"); 
	}

	function post_undo_pelanggaran($id_pelanggaran)
	{
		return $this->db->query("UPDATE pelanggaran SET pelanggaran.status_pelanggaran = 1 WHERE pelanggaran.id_pelanggaran = '".$id_pelanggaran."';");
	}
}
?>